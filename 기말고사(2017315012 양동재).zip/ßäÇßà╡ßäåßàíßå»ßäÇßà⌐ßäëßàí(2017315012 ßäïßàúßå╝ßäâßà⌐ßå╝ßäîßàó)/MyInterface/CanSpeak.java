package MyInterface;


/**
 * Void 메서드 선언
 *
 * @author (2017315012 양동재)
 * @version (2020.06.30)
 */
public interface CanSpeak
{
    public void say();
}
