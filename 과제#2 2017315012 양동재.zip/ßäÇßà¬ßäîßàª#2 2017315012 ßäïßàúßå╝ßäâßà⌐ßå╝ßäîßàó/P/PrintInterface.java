package P;


/**
 * Write a description of interface PrintInterface here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface PrintInterface
{
    public abstract void printOperator();
}
